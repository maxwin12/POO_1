import tkinter as tk
from tkinter import ttk
import sqlite3
from datetime import datetime


# Garment Class
class Garment:
    def __init__(self, garment_type, price):
        self.garment_type = garment_type
        self.price = price
        self.garment_id = None  # Initialize without an ID

    def save_to_db(self, order_id):
        conn = sqlite3.connect("dry-cleaners.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO garments (order_id, garment_type, price) VALUES (?, ?, ?)",
            (order_id, self.garment_type, self.price),
        )
        conn.commit()
        self.garment_id = cursor.lastrowid
        conn.close()


# Order Class
class Order:
    def __init__(self, client_id):
        self.order_id = None  # ID will be assigned by the database
        self.client_id = client_id
        self.garments = []
        self.date = datetime.now()
        self.total_price = 0

    def calculate_total(self):
        self.total_price = sum(garment.price for garment in self.garments)

    def save_to_db(self):
        conn = sqlite3.connect("dry-cleaners.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO orders (client_id, date, total_price) VALUES (?, ?, ?)",
            (self.client_id, self.date, self.total_price),
        )
        conn.commit()
        self.order_id = cursor.lastrowid
        conn.close()


def main_searcher(root, selected_client):
    def select_client(event):
        selected = list_box.curselection()
        if selected:
            # Extract the client ID from the selected item
            client_info = list_box.get(selected[0])
            try:
                client_id = int(client_info.split(",")[0].split(":")[1].strip())  # Extract ID safely
                selected_client.set(client_id)  # Store the selected client ID
            except (IndexError, ValueError):
                selected_client.set("")  # Clear selection if parsing fails

    tk.Label(root, text="Buscar Cliente").grid(row=0, column=0, columnspan=3, pady=5)

    search_value = tk.StringVar()
    search_entry = tk.Entry(root, textvariable=search_value, width=25)
    search_entry.grid(row=1, column=0, columnspan=2, padx=5, pady=5, sticky="we")

    def search():
        v = search_value.get().lower()
        conn = sqlite3.connect("dry-cleaners.db")
        cursor = conn.cursor()
        cursor.execute(
            "SELECT client_id, name, contact_info FROM clients WHERE name LIKE ? OR contact_info LIKE ?",
            (f"%{v}%", f"%{v}%"),
        )
        clients = cursor.fetchall()
        conn.close()
        list_box.delete(0, tk.END)
        for client in clients:
            list_box.insert(
                tk.END, f"ID: {client[0]}, Name: {client[1]}, Contact: {client[2]}"
            )

    tk.Button(root, text="Search", command=search).grid(row=1, column=2, padx=5)

    list_box = tk.Listbox(root, width=50, height=5)
    list_box.grid(row=2, column=0, columnspan=3, pady=10, padx=10, sticky="nsew")
    list_box.bind("<<ListboxSelect>>", select_client)  # Single-click to select



# New Order Window
def open_new_order_window():
    """Creates a new order window."""
    create_order_window = tk.Toplevel()
    create_order_window.title("Crear Nuevo Pedido")
    create_order_window.geometry("600x500")

    selected_client = tk.StringVar()  # Store selected client ID

    # Frame for client selection
    client_frame = tk.Frame(create_order_window)
    client_frame.grid(row=0, column=0, columnspan=3, pady=10, padx=10, sticky="nsew")
    main_searcher(client_frame, selected_client)

    # Predefined prices for garments
    prendas_disponibles = {
        "Camisa": 50.00,
        "Pantalón": 75.00,
        "Vestido": 120.00,
        "Falda": 90.00,
        "Traje": 200.00,
        "Blusa": 60.00,
    }

    prendas_seleccionadas = []  # List of selected garments

    # Prenda Selection
    tk.Label(create_order_window, text="Selecciona una prenda:").grid(
        row=1, column=0, pady=5, sticky="w"
    )
    combo_prendas = ttk.Combobox(
        create_order_window, values=list(prendas_disponibles.keys()), state="readonly"
    )
    combo_prendas.grid(row=1, column=1, pady=5, padx=10, sticky="we")

    # Listbox for selected garments
    tk.Label(create_order_window, text="Prendas seleccionadas:").grid(
        row=2, column=0, pady=5, sticky="w"
    )
    listbox_prendas = tk.Listbox(create_order_window, height=10, width=40)
    listbox_prendas.grid(row=3, column=0, columnspan=3, pady=5, padx=10, sticky="nsew")

    def agregar_prenda():
        prenda = combo_prendas.get()
        if not prenda:
            tk.messagebox.showerror("Error", "Seleccione una prenda.")
            return

        # Get the price from the dictionary
        price = prendas_disponibles[prenda]
        prendas_seleccionadas.append(Garment(prenda, price))

        # Add garment with price to the Listbox
        listbox_prendas.insert(tk.END, f"{prenda} - ${price:.2f}")

        # Clear selection
        combo_prendas.set("")

    def guardar_prendas():
        client_id = selected_client.get()
        if not client_id:
            tk.Label(create_order_window, text="Seleccione un cliente antes de guardar.", fg="red").grid(
                row=7, column=0, columnspan=3, pady=5
            )
            return

        # Create order
        order = Order(client_id)
        order.garments = prendas_seleccionadas
        order.calculate_total()
        order.save_to_db()

        # Save garments
        for garment in order.garments:
            garment.save_to_db(order.order_id)

        tk.Label(create_order_window, text="Pedido guardado correctamente.", fg="green").grid(
            row=7, column=0, columnspan=3, pady=5
        )
        create_order_window.after(2000, create_order_window.destroy)  # Close the window after 2 seconds

    # Buttons
    tk.Button(create_order_window, text="Agregar Prenda", command=agregar_prenda).grid(
        row=4, column=0, pady=5, padx=5
    )
    tk.Button(
        create_order_window, text="Guardar Prendas", command=guardar_prendas
    ).grid(row=4, column=2, pady=5, padx=5)



# Main Window for Testing
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Sistema de Tintorería")
    root.geometry("300x200")

    btn_open_order = tk.Button(root, text="Crear Nuevo Pedido", command=open_new_order_window)
    btn_open_order.pack(pady=20)

    root.mainloop()




# Hacer que se guarden las prendas en la base de datos, hacer una ventana donde se busque a los clientes para seleccionarlo, y si no hay que se habra una ventana para crear uno nuevo. ponerle precio a las prendas.



    
    # hacer una ventana que abra los clientes disponibles y que cuando se ahag doble click se seleccione, se vuelva a abrir la venta donde se esta creando la orden y se ponga confirmar orden