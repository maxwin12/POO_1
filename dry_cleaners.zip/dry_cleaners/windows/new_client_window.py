# windows/client_management_window.py

import tkinter as tk
from tkinter import messagebox
from structures.client import Client
from windows.order_management_window import open_order_management_window
import sqlite3

def printdata(v):
    print(v)

def open_new_client_window():
    """Opens a new window to create a new client."""
    create_client_window = tk.Toplevel()
    create_client_window.title("Create New Client")

    # Label and Entry for Client Name
    tk.Label(create_client_window, text="Name:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
    name_entry = tk.Entry(create_client_window)
    name_entry.grid(row=0, column=1, padx=10, pady=10)

    # Label and Entry for client contact info 
    tk.Label(create_client_window, text="Contact info: ").grid(row=1, column=0, padx=10, pady=10, sticky="e")
    contact_info_entry = tk.Entry(create_client_window)
    contact_info_entry.grid(row=1, column=1, padx=10, pady=10)


    def create_new_client():
        name = name_entry.get()
        contact = contact_info_entry.get()
        if name and contact:
            conn = sqlite3.connect("dry-cleaners.db")
            cursor = conn.cursor()
            cursor.execute("SELECT name, contact_info FROM clients WHERE contact_info = ?", (contact, ))
            duplicated = cursor.fetchall()
            if duplicated:
                tk.messagebox.showinfo("ERROR", f"ERROR Duplicated\nName: {duplicated[0][0]}\nContact-Info: {duplicated[0][1]}")
            else:
                client = Client(name, contact)
                client.save_to_db()
                print("Client saved...")
        else:
            tk.messagebox.showinfo("Argument Missing", "Complete all the inputs")

    

    # Create button
    tk.Button(create_client_window, text="Submit", command=create_new_client).grid(row=2, column=0, columnspan=2, pady=20)




    
