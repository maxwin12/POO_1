import sqlite3
import tkinter as tk

def open_edit_order_window(data):
    window = tk.Toplevel()
    window.title("View/Edit Order")
    
    id_n = data.split(",")
    id_n = id_n[0][9:]

    conn = sqlite3.connect("dry-cleaners.db")
    cursor = conn.cursor()
    cursor.execute("SELECT price FROM garments WHERE order_id = ?", (int(id_n),))
    total_price = cursor.fetchall()
    total_price = sum([garment_price[0] for garment_price in total_price])
    conn.commit()

    tk.Label(window, text=f"Order {id_n}").grid(row=0, column=0)
    tk.Label(window, text=f"Total Price: {total_price}").grid(row=0, column=5)

    cursor.execute("SELECT garment_id, garment_type, price FROM garments WHERE order_id = ?", (int(id_n),))
    garments = cursor.fetchall()
    conn.commit()
    conn.close()
    
    list_box = tk.Listbox(window, width=40, height=5)
    list_box.grid(row=2, column=0, columnspan=8, padx=5)

    for garment in garments:
        result = f"{garment[0]}- Type: {garment[1]}, Price: {garment[2]}"
        list_box.insert(tk.END, result)


    
