# windows/order_management_window.py

import tkinter as tk
from structures.order import Order
import sqlite3
from windows.edit_order import open_edit_order_window
def open_order_management_window():
    order_window = tk.Toplevel()  # Create a new top-level window
    order_window.title("Order Management")
    order_window.geometry("400x200")

    # Placeholder label for now
    #tk.Label(order_window, text="Order Management Window").pack(padx=20, pady=20)
    
    # Label and Entry for a nav bar
    tk.Label(order_window, text="Search by traking number ID: ").grid(row=1, column=0, padx=10, pady=10)

    search_var = tk.StringVar()
    search_order_entry = tk.Entry(order_window, textvariable=search_var)
    search_order_entry.grid(row=1, column=1, columnspan=3)

    def update_search_results(*args):
        # Clear current contents in the listbox
        result_listbox.delete(0, tk.END)
        # Get the current search input
        search_text = search_var.get().lower()
        # Filter client names that match the search text
        conn = sqlite3.connect("dry-cleaners.db")
        cursor = conn.cursor()
        cursor.execute("SELECT order_id, client_id,date, total_price FROM orders WHERE CAST(order_id as TEXT) LIKE ?", (search_text + '%',))
        results = cursor.fetchall()
        conn.close()
        for result in results:
            # Format the result tuple as a single string
            result_text = f"Order ID: {result[0]}, Client ID: {result[1]}, Date: {result[2]}, Total Price: ${result[3]}"
            result_listbox.insert(tk.END, result_text)  # Insert each formatted string into the Listbox

    
    tk.Button(order_window, text="Search", command=update_search_results).grid(row=2, column=3)
    # Listbox to show search results
    result_listbox = tk.Listbox(order_window, width=40, height=5)
    result_listbox.grid(row=3, column=0, columnspan=8)

    def on_double_click(event):
        selected_index = result_listbox.curselection()
        if selected_index:
            selected_value = result_listbox.get(selected_index[0])
            #print(selected_index)  Test if the event fires
            # Show the selected value in a message box
            open_edit_order_window(selected_value)



    result_listbox.bind("<Double-1>", on_double_click)