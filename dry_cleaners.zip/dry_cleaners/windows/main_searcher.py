import tkinter as tk
import sqlite3


def main_searcher(root):

    
    tk.Label(root, text="Dry-Cleaners").grid(row=1, column=0, pady=5)
    # Create a string var
    search_value = tk.StringVar()
    # Create an Entry to search by name or phone number
    search_entry = tk.Entry(root, textvariable=search_value)
    search_entry.grid(row=1, column=1, pady=5) #adjust columnspan


    # Create a button to search and a function 
    def search():
        v = search_value.get().lower()
        conn = sqlite3.connect("dry-cleaners.db")
        cursor = conn.cursor()
        cursor.execute("SELECT name, contact_info FROM clients WHERE name LIKE ? OR contact_info LIKE ?", (f"%{v}%", f"{v}%"))
        clients = cursor.fetchall()

        conn.commit()
        conn.close()
        list_box.delete(0, tk.END)
        for client in clients:
            info = f"Client: {client[0]}, Contact-Info: {client[1]}"
            list_box.insert(tk.END, info)

    button_search = tk.Button(root, text="Search", command=search)
    button_search.grid(row=1, column=2, pady=5)



    list_box = tk.Listbox(root, width=40, height=5)
    list_box.grid(row=2, column=0, columnspan=8, padx=5)

    # Create a function to display all clients
    
    
