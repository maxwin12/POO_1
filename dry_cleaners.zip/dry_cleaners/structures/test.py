from client import Client
from order import Order
from garment import Garment
import sqlite3

data = []

if data:
    print("HELLO")
else:
    print("Empty")