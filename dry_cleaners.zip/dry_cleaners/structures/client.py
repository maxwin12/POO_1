# name, phone_number, garments, direction(Optional)
import sqlite3 
class Client:
    def __init__(self, name, contact_info):
        self.client_id = None # ID will be assigned by the database
        self.name = name 
        self.contact_info = contact_info


    
    def save_to_db(self):
        # Connect to the database
        conn = sqlite3.connect('dry-cleaners.db')
        cursor = conn.cursor()
        
        # Insert data into the clients table
        cursor.execute("INSERT OR REPLACE INTO clients (client_id, name, contact_info) VALUES (?, ?, ?)", (self.client_id, self.name, self.contact_info))
        
        # Commit and close the connection
        conn.commit()
        self.client_id = cursor.lastrowid
        conn.close()
    
    def update_info(self, name=None, contact_info=None):
        # Update client info if new data is provided
        if name:
            self.name = name
        if contact_info:
            self.contact_info = contact_info
        
        conn = sqlite3.connect('dry-cleaners.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE clients SET name = ?, contact_info = ? Where client_id =?", (self.name, self.contact_info, self.client_id))

        conn.commit()
        conn.close()

    def delete_from_db(self, client_id):
        conn = sqlite3.connect('dry-cleaners.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM clients WHERE client_id = ?", (client_id,))

