from datetime import datetime
import sqlite3

class Order:
    def __init__(self, client):
        self.order_id = None # ID will be assigned by the database
        self.client = client
        self.garments = []
        self.date = datetime.now() 
        self.total_price = 0
    
    def save_to_db(self):
        # Connect to the database
        conn = sqlite3.connect('dry-cleaners.db')
        cursor = conn.cursor()

        # Insert data into the orders table
        cursor.execute("INSERT OR REPLACE INTO orders (order_id, client_id, date, total_price) VALUES (?, ?, ?, ?)", (self.order_id, self.client.client_id, self.date, self.total_price))

        # Commit and close the connection
        conn.commit()
        self.client_id = cursor.lastrowid
        conn.close()

    def delete_from_db(self):
        conn = sqlite3.connect('dry-cleaners.py')
        cursor = conn.cursor()

        # Delete associated garments first
        cursor.execute("DELETE FROM garments WHERE order_id = ?", (self.order_id))
        # Then delete the order
        cursor.execute("DELETE FORM orders WHERE order_id = ?", (self.order_id))

