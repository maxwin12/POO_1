import sqlite3

# Connect to the database
conn = sqlite3.connect('dry-cleaners.db')
cursor = conn.cursor()

# Fetch and print all clients
print("Clients Table:")
cursor.execute("SELECT * FROM clients")
clients = cursor.fetchall()
for client in clients:
    print(client)

# Fetch and print all orders
print("\nOrders Table:")
cursor.execute("SELECT * FROM orders")
orders = cursor.fetchall()
for order in orders:
    print(order)

# Fetch and print all garments
print("\nGarments Table:")
cursor.execute("SELECT * FROM garments")
garments = cursor.fetchall()
for garment in garments:
    print(garment)

# Close the connection
conn.close()
