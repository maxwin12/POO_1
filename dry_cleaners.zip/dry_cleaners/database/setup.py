import sqlite3

# Connect to the database (this will create dry-cleaners.db if it doesn't exist)
conn = sqlite3.connect('dry-cleaners.db')
cursor = conn.cursor()

# Create a table for clients
cursor.execute('''
    CREATE TABLE IF NOT EXISTS clients (
        client_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact_info TEXT NOT NULL
    )
''')

# Create a table for orders
cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        order_id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id INTEGER,
        date TEXT,
        total_price REAL,
        FOREIGN KEY (client_id) REFERENCES clients(client_id)
    )
''')

# Create a table for garments within orders
cursor.execute('''
    CREATE TABLE IF NOT EXISTS garments (
        garment_id INTEGER PRIMARY KEY,
        order_id INTEGER,
        garment_type TEXT,
        price REAL,
        FOREIGN KEY (order_id) REFERENCES orders(order_id)
    )
''')

# Commit and close the connection
conn.commit()
conn.close()
