# main_window.py

import tkinter as tk
from tkinter import Menu
from windows.new_client_window import open_new_client_window
from windows.order_management_window import open_order_management_window
from windows.new_order_window import open_new_order_window
from windows.main_searcher import main_searcher

class MainApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("Dry Cleaners Management System")
        self.root.geometry("400x200")
        # Create the menu bar
        menubar = Menu(self.root)

        # Add "Management" menu with options
        management_menu = Menu(menubar, tearoff=0)
        management_menu.add_command(label="New Client", command=open_new_client_window)
        management_menu.add_command(label="Order Management", command=open_order_management_window)
        management_menu.add_command(label="New Order", command=open_new_order_window)

        # Add the management menu to the menu bar
        menubar.add_cascade(label="Management", menu=management_menu)

        # Configure the menu bar on the root window
        self.root.config(menu=menubar)

        # Put the searcher
        main_searcher(self.root)

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApplication(root)
    root.mainloop()
